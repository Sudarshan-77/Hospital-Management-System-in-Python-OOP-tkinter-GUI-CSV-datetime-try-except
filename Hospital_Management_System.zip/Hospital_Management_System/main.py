from datetime import datetime
import csv
import os
import shutil
import unicodedata
import tkinter as tk
from tkinter import ttk, messagebox

PATIENTS_FILE = "patients.csv"
DOCTORS_FILE = "doctors.csv"
APPOINTMENTS_FILE = "appointments.csv"

PATIENT_PREFIX = "P"
DOCTOR_PREFIX = "D"
APPOINTMENT_PREFIX = "Apt"
ID_DIGITS = 4

# utf-8-sig lets Excel show non-English (for example Nepali) text correctly
FILE_ENCODING = "utf-8-sig"

# ------------------------------------------------------------------------------------------------------
# Validations


def is_letter(ch):
    """True for letters of any language, including the signs used in Nepali (Devanagari) words."""
    return unicodedata.category(ch)[0] in ("L", "M")


def require_name(value, field_name):
    value = str(value).strip()

    if value == "":
        raise ValueError(field_name + " cannot be empty.")
    if len(value) < 2 or len(value) > 50:
        raise ValueError(field_name + " must be between 2 and 50 characters, got '" + value + "'.")
    if "  " in value:
        raise ValueError(field_name + " cannot contain double spaces, got '" + value + "'.")

    letter_count = 0
    for ch in value:
        if is_letter(ch):
            letter_count = letter_count + 1
        elif ch not in " -'.":
            raise ValueError(field_name + " can contain only letters, spaces, '-', ''' and '.', got '" + value + "'.")

    if letter_count < 2:
        raise ValueError(field_name + " must contain at least 2 letters, got '" + value + "'.")

    return value


def require_age(value, minimum=0, maximum=130):
    try:
        age = int(value)
    except (ValueError, TypeError):
        raise ValueError("Age must be a whole number, got '" + str(value) + "'.")
    if age < minimum or age > maximum:
        raise ValueError("Age must be between " + str(minimum) + " and " + str(maximum) + ", got " + str(age) + ".")
    return age


def require_phone(value):
    value = str(value).strip()

    if not value.isascii() or not value.isdigit() or len(value) != 10:
        raise ValueError("Phone must contain exactly 10 digits, got '" + value + "'.")
    if not (value.startswith("98") or value.startswith("97")):
        raise ValueError("Phone must start with '98' or '97', got '" + value + "'.")
    if value == value[0] * len(value):
        raise ValueError("Phone cannot be the same digit repeated, got '" + value + "'.")

    return value


def require_date(value):
    """Checks the FORMAT only (used when loading from the file, so old appointments still load)."""
    value = str(value).strip()
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        raise ValueError("Date must be in YYYY-MM-DD format, got '" + value + "'.")
    return value


def require_future_or_today_date(value):
    """Used only when BOOKING a new appointment."""
    value = require_date(value)
    appointment_date = datetime.strptime(value, "%Y-%m-%d")
    today = datetime.now()
    if appointment_date.date() < today.date():
        raise ValueError("Appointment date cannot be in the past, got '" + value + "'.")
    return value


def require_description(value, field_name):
    value = str(value).strip()

    if value == "":
        raise ValueError(field_name + " cannot be empty.")
    if len(value) < 2 or len(value) > 50:
        raise ValueError(field_name + " must be between 2 and 50 characters, got '" + value + "'.")

    for ch in value:
        if not (is_letter(ch) or ch.isdigit() or ch in " -,./()"):
            raise ValueError(field_name + " can contain only letters, numbers, spaces and - , . / ( ), got '" + value + "'.")

    return value


def require_id_format(value, prefix, digit_count, field_name):
    """
    Checks that an ID looks like: <prefix> followed by exactly
    digit_count digits. Example: require_id_format("P0007", "P", 4, "Patient ID")
    """
    value = str(value).strip()

    if not value.startswith(prefix):
        raise ValueError(field_name + " must start with '" + prefix + "', got '" + value + "'.")

    number_part = value[len(prefix):]
    if len(number_part) != digit_count or not number_part.isascii() or not number_part.isdigit():
        example = prefix + ("0" * (digit_count - 1)) + "1"
        raise ValueError(field_name + " must be '" + prefix + "' followed by exactly " +
                         str(digit_count) + " digits (example: " + example + "), got '" + value + "'.")

    return value


def generate_next_id(objects, prefix, digit_count):
    """
    Looks at existing IDs (like P0001, P0002, ...) and returns the next
    one in line, always padded to digit_count digits.
    """
    highest_number = 0
    for obj in objects:
        number = int(obj.id[len(prefix):])
        if number > highest_number:
            highest_number = number

    next_number = highest_number + 1
    if next_number > (10 ** digit_count) - 1:
        raise ValueError("The limit of " + str((10 ** digit_count) - 1) + " records has been reached.")

    number_text = str(next_number)
    while len(number_text) < digit_count:
        number_text = "0" + number_text

    return prefix + number_text


# ---------------------------------------------------------------------------
# Person -> [Patient, Doctor]

class Person:
    min_age = 0

    def __init__(self, id, name, age, phone):
        self.id = id
        self.name = require_name(name, "Name")
        self.age = require_age(age, self.min_age)
        self.phone = require_phone(phone)

    def display(self):
        pass


class Patient(Person):
    fields = ["id", "name", "age", "phone", "disease"]  # CSV column order

    def __init__(self, id, name, age, phone, disease):
        id = require_id_format(id, PATIENT_PREFIX, ID_DIGITS, "Patient ID")
        Person.__init__(self, id, name, age, phone)
        self.disease = require_description(disease, "Disease")

    def display(self):
        return ("Patient " + self.id + ": " + self.name + ", " + str(self.age) +
                " yrs, " + self.phone + " - " + self.disease)


class Doctor(Person):
    fields = ["id", "name", "age", "phone", "specialization"]
    min_age = 21  # a doctor must be an adult

    def __init__(self, id, name, age, phone, specialization):
        id = require_id_format(id, DOCTOR_PREFIX, ID_DIGITS, "Doctor ID")
        Person.__init__(self, id, name, age, phone)
        self.specialization = require_description(specialization, "Specialization")

    def display(self):
        return ("Doctor " + self.id + ": Dr. " + self.name + ", " + str(self.age) +
                " yrs, " + self.phone + " - " + self.specialization)


class Appointment:
    fields = ["id", "patient_id", "doctor_id", "date"]

    def __init__(self, id, patient_id, doctor_id, date):
        self.id = require_id_format(id, APPOINTMENT_PREFIX, ID_DIGITS, "Appointment ID")
        self.patient_id = require_id_format(patient_id, PATIENT_PREFIX, ID_DIGITS, "Patient ID")
        self.doctor_id = require_id_format(doctor_id, DOCTOR_PREFIX, ID_DIGITS, "Doctor ID")
        # Format only. The "not in the past" rule is checked when booking, not when loading.
        self.date = require_date(date)

    def display(self):
        return ("Appointment " + self.id + ": Patient " + self.patient_id +
                " with Doctor " + self.doctor_id + " on " + self.date)


# ---------------------------------------------------------------------------
# CSV read/write helpers

def write_csv(filename, objects, fields):
    """Writes to a temporary file first, so a crash can never leave a half-written CSV."""
    temp_name = filename + ".tmp"
    with open(temp_name, "w", newline="", encoding=FILE_ENCODING) as file:
        writer = csv.writer(file)
        writer.writerow(fields)
        for obj in objects:
            row = []
            for field in fields:
                row.append(getattr(obj, field))
            writer.writerow(row)
    os.replace(temp_name, filename)


def backup_file(filename):
    backup_name = filename + "." + datetime.now().strftime("%Y%m%d_%H%M%S") + ".bak"
    shutil.copyfile(filename, backup_name)
    return backup_name


def read_csv(filename, cls, fields):
    """
    Returns (objects, warnings). Bad rows never crash the program; they are listed
    in warnings, and a backup copy of the original file is made before anything
    can be overwritten.
    """
    objects = []
    warnings = []

    if not os.path.exists(filename):
        return objects, warnings

    with open(filename, newline="", encoding=FILE_ENCODING) as file:
        reader = csv.DictReader(file)

        if reader.fieldnames is None:  # empty file
            return objects, warnings

        missing = []
        for field in fields:
            if field not in reader.fieldnames:
                missing.append(field)

        if len(missing) > 0:
            warnings.append(filename + ": missing column(s) " + ", ".join(missing) + ". The file was not loaded.")
        else:
            line_number = 1
            for row in reader:
                line_number = line_number + 1
                values = {}
                for field in fields:
                    values[field] = row.get(field)

                try:
                    if None in values.values():
                        raise ValueError("the row has missing values")
                    objects.append(cls(**values))
                except (ValueError, TypeError) as e:
                    warnings.append(filename + " line " + str(line_number) + ": " + str(e))

    if len(warnings) > 0:
        backup_name = backup_file(filename)
        warnings.append("A backup of " + filename + " was saved as " + backup_name)

    return objects, warnings


# ---------------------------------------------------------------------------
# Hospital: holds everything in plain lists

class Hospital:
    def __init__(self):
        self.load_warnings = []

        self.patients, warnings = read_csv(PATIENTS_FILE, Patient, Patient.fields)
        self.load_warnings = self.load_warnings + warnings

        self.doctors, warnings = read_csv(DOCTORS_FILE, Doctor, Doctor.fields)
        self.load_warnings = self.load_warnings + warnings

        self.appointments, warnings = read_csv(APPOINTMENTS_FILE, Appointment, Appointment.fields)
        self.load_warnings = self.load_warnings + warnings

        orphans = 0
        for a in self.appointments:
            if self.find_patient(a.patient_id) is None or self.find_doctor(a.doctor_id) is None:
                orphans = orphans + 1
        if orphans > 0:
            self.load_warnings.append(str(orphans) + " appointment(s) refer to a patient or doctor that no longer exists.")

    # ----- saving -----
    def save(self):
        write_csv(PATIENTS_FILE, self.patients, Patient.fields)
        write_csv(DOCTORS_FILE, self.doctors, Doctor.fields)
        write_csv(APPOINTMENTS_FILE, self.appointments, Appointment.fields)

    def save_or_undo(self, undo):
        """Saves; if the file cannot be written, undo() restores the lists and an error is raised."""
        try:
            self.save()
        except OSError as e:
            undo()
            raise ValueError("Could not save the data file. Close it if it is open in another program. (" + str(e) + ")")

    # ----- add -----
    def add_patient(self, name, age, phone, disease):
        phone = require_phone(phone)
        for p in self.patients:
            if p.phone == phone:
                raise ValueError("Phone '" + phone + "' is already used by another patient.")

        new_id = generate_next_id(self.patients, PATIENT_PREFIX, ID_DIGITS)
        new_patient = Patient(new_id, name, age, phone, disease)
        self.patients.append(new_patient)
        self.save_or_undo(lambda: self.patients.remove(new_patient))
        return new_patient

    def add_doctor(self, name, age, phone, specialization):
        phone = require_phone(phone)
        for d in self.doctors:
            if d.phone == phone:
                raise ValueError("Phone '" + phone + "' is already used by another doctor.")

        new_id = generate_next_id(self.doctors, DOCTOR_PREFIX, ID_DIGITS)
        new_doctor = Doctor(new_id, name, age, phone, specialization)
        self.doctors.append(new_doctor)
        self.save_or_undo(lambda: self.doctors.remove(new_doctor))
        return new_doctor

    def book_appointment(self, patient_id, doctor_id, date):
        # Validate and clean EVERYTHING first, so the duplicate checks below use clean values.
        patient_id = require_id_format(str(patient_id).strip().upper(), PATIENT_PREFIX, ID_DIGITS, "Patient ID")
        doctor_id = require_id_format(str(doctor_id).strip().upper(), DOCTOR_PREFIX, ID_DIGITS, "Doctor ID")
        date = require_future_or_today_date(date)

        if self.find_patient(patient_id) is None:
            raise ValueError("No patient with ID '" + patient_id + "'.")
        if self.find_doctor(doctor_id) is None:
            raise ValueError("No doctor with ID '" + doctor_id + "'.")

        # A doctor can't have two appointments on the same day.
        for a in self.appointments:
            if a.doctor_id == doctor_id and a.date == date:
                raise ValueError("Doctor '" + doctor_id + "' already has an appointment on " + date + ".")

        # A patient can't book two appointments on the same day either.
        for a in self.appointments:
            if a.patient_id == patient_id and a.date == date:
                raise ValueError("Patient '" + patient_id + "' already has an appointment on " + date + ".")

        new_id = generate_next_id(self.appointments, APPOINTMENT_PREFIX, ID_DIGITS)
        new_appointment = Appointment(new_id, patient_id, doctor_id, date)
        self.appointments.append(new_appointment)
        self.save_or_undo(lambda: self.appointments.remove(new_appointment))
        return new_appointment

    # ----- find -----
    def find_patient(self, id):
        for p in self.patients:
            if p.id == id:
                return p
        return None

    def find_doctor(self, id):
        for d in self.doctors:
            if d.id == id:
                return d
        return None

    def find_appointment(self, id):
        for a in self.appointments:
            if a.id == id:
                return a
        return None

    def count_patient_appointments(self, patient_id):
        count = 0
        for a in self.appointments:
            if a.patient_id == patient_id:
                count = count + 1
        return count

    def count_doctor_appointments(self, doctor_id):
        count = 0
        for a in self.appointments:
            if a.doctor_id == doctor_id:
                count = count + 1
        return count

    # ----- delete (also removes the person's appointments, so nothing is left pointing at a wrong person) -----
    def delete_patient(self, id):
        patient = self.find_patient(id)
        if patient is None:
            return False

        old_appointments = list(self.appointments)
        old_position = self.patients.index(patient)

        remaining = []
        for a in self.appointments:
            if a.patient_id != id:
                remaining.append(a)
        self.appointments = remaining
        self.patients.remove(patient)

        def undo():
            self.patients.insert(old_position, patient)
            self.appointments = old_appointments

        self.save_or_undo(undo)
        return True

    def delete_doctor(self, id):
        doctor = self.find_doctor(id)
        if doctor is None:
            return False

        old_appointments = list(self.appointments)
        old_position = self.doctors.index(doctor)

        remaining = []
        for a in self.appointments:
            if a.doctor_id != id:
                remaining.append(a)
        self.appointments = remaining
        self.doctors.remove(doctor)

        def undo():
            self.doctors.insert(old_position, doctor)
            self.appointments = old_appointments

        self.save_or_undo(undo)
        return True

    def cancel_appointment(self, id):
        appointment = self.find_appointment(id)
        if appointment is None:
            return False

        old_position = self.appointments.index(appointment)
        self.appointments.remove(appointment)
        self.save_or_undo(lambda: self.appointments.insert(old_position, appointment))
        return True

    # ----- search / display -----
    def search(self, name):
        name = name.strip().lower()
        matches = []
        for p in self.patients:
            if name in p.name.lower():
                matches.append(p)
        for d in self.doctors:
            if name in d.name.lower():
                matches.append(d)
        return matches

    def describe_appointment(self, a):
        patient = self.find_patient(a.patient_id)
        doctor = self.find_doctor(a.doctor_id)
        patient_text = a.patient_id
        doctor_text = a.doctor_id
        if patient is not None:
            patient_text = a.patient_id + " " + patient.name
        if doctor is not None:
            doctor_text = a.doctor_id + " Dr. " + doctor.name
        return "Appointment " + a.id + ": " + patient_text + " with " + doctor_text + " on " + a.date


# ---------------------------------------------------------------------------
# GUI: built with tkinter (comes built in with Python, nothing to install)

class HospitalApp:
    def __init__(self, root):
        self.hospital = Hospital()
        self.root = root
        self.root.title("Hospital Management System")
        self.root.geometry("760x620")

        notebook = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.patient_tab = tk.Frame(notebook)
        self.doctor_tab = tk.Frame(notebook)
        self.appointment_tab = tk.Frame(notebook)
        self.search_tab = tk.Frame(notebook)

        notebook.add(self.patient_tab, text="Patients")
        notebook.add(self.doctor_tab, text="Doctors")
        notebook.add(self.appointment_tab, text="Appointments")
        notebook.add(self.search_tab, text="Search")

        self.build_patient_tab()
        self.build_doctor_tab()
        self.build_appointment_tab()
        self.build_search_tab()

        if len(self.hospital.load_warnings) > 0:
            self.root.after(300, self.show_load_warnings)

    def show_load_warnings(self):
        lines = self.hospital.load_warnings[:12]
        text = "\n".join(lines)
        if len(self.hospital.load_warnings) > 12:
            text = text + "\n... and " + str(len(self.hospital.load_warnings) - 12) + " more."
        messagebox.showwarning("Some data could not be loaded", text)

    def make_listbox(self, parent, row, height):
        """A listbox with scrollbars, so long lines and long lists are fully visible."""
        holder = tk.Frame(parent)
        holder.grid(row=row, column=0, columnspan=2, padx=5, pady=5, sticky="nsew")

        listbox = tk.Listbox(holder, width=90, height=height, exportselection=False)
        y_bar = tk.Scrollbar(holder, orient="vertical", command=listbox.yview)
        x_bar = tk.Scrollbar(holder, orient="horizontal", command=listbox.xview)
        listbox.config(yscrollcommand=y_bar.set, xscrollcommand=x_bar.set)

        x_bar.pack(side="bottom", fill="x")
        y_bar.pack(side="right", fill="y")
        listbox.pack(side="left", fill="both", expand=True)
        return listbox

    def selected_id(self, listbox, word):
        """Reads the ID out of a selected line such as 'Patient P0001: ...'. Returns None if nothing is selected."""
        selection = listbox.curselection()
        if len(selection) == 0:
            return None
        row_text = listbox.get(selection[0])
        return row_text.split(":")[0].replace(word, "").strip()

    # -----------------------------------------------------------------
    # Patients tab
    # -----------------------------------------------------------------
    def build_patient_tab(self):
        frame = self.patient_tab

        tk.Label(frame, text="Name:").grid(row=0, column=0, sticky="e", padx=5, pady=3)
        self.patient_name_entry = tk.Entry(frame, width=30)
        self.patient_name_entry.grid(row=0, column=1, sticky="w", pady=3)

        tk.Label(frame, text="Age:").grid(row=1, column=0, sticky="e", padx=5, pady=3)
        self.patient_age_entry = tk.Entry(frame, width=30)
        self.patient_age_entry.grid(row=1, column=1, sticky="w", pady=3)

        tk.Label(frame, text="Phone:").grid(row=2, column=0, sticky="e", padx=5, pady=3)
        self.patient_phone_entry = tk.Entry(frame, width=30)
        self.patient_phone_entry.grid(row=2, column=1, sticky="w", pady=3)

        tk.Label(frame, text="Disease:").grid(row=3, column=0, sticky="e", padx=5, pady=3)
        self.patient_disease_entry = tk.Entry(frame, width=30)
        self.patient_disease_entry.grid(row=3, column=1, sticky="w", pady=3)

        tk.Button(frame, text="Add Patient", command=self.add_patient).grid(row=4, column=0, columnspan=2, pady=6)

        self.patient_listbox = self.make_listbox(frame, 5, 12)

        tk.Button(frame, text="Delete Selected", command=self.delete_patient).grid(row=6, column=0, columnspan=2, pady=4)

        self.refresh_patients()

    def add_patient(self):
        try:
            new_patient = self.hospital.add_patient(
                self.patient_name_entry.get(),
                self.patient_age_entry.get(),
                self.patient_phone_entry.get(),
                self.patient_disease_entry.get())
        except ValueError as e:
            messagebox.showerror("Error", str(e))
            return

        messagebox.showinfo("Success", "Patient added with ID: " + new_patient.id)
        self.patient_name_entry.delete(0, tk.END)
        self.patient_age_entry.delete(0, tk.END)
        self.patient_phone_entry.delete(0, tk.END)
        self.patient_disease_entry.delete(0, tk.END)
        self.refresh_patients()

    def delete_patient(self):
        id_value = self.selected_id(self.patient_listbox, "Patient")
        if id_value is None:
            messagebox.showerror("Error", "Select a patient to delete first.")
            return

        count = self.hospital.count_patient_appointments(id_value)
        question = "Delete patient " + id_value + "?"
        if count > 0:
            question = question + "\nTheir " + str(count) + " appointment(s) will be deleted too."
        if not messagebox.askyesno("Confirm delete", question):
            return

        try:
            deleted = self.hospital.delete_patient(id_value)
        except ValueError as e:
            messagebox.showerror("Error", str(e))
            return

        if deleted:
            messagebox.showinfo("Deleted", "Patient " + id_value + " deleted.")
            self.refresh_patients()
            self.refresh_appointments()
        else:
            messagebox.showerror("Error", "Patient not found.")

    def refresh_patients(self):
        self.patient_listbox.delete(0, tk.END)
        for p in self.hospital.patients:
            self.patient_listbox.insert(tk.END, p.display())
        if hasattr(self, "appt_patient_combo"):
            self.refresh_appointment_choices()

    # -----------------------------------------------------------------
    # Doctors tab
    # -----------------------------------------------------------------
    def build_doctor_tab(self):
        frame = self.doctor_tab

        tk.Label(frame, text="Name:").grid(row=0, column=0, sticky="e", padx=5, pady=3)
        self.doctor_name_entry = tk.Entry(frame, width=30)
        self.doctor_name_entry.grid(row=0, column=1, sticky="w", pady=3)

        tk.Label(frame, text="Age:").grid(row=1, column=0, sticky="e", padx=5, pady=3)
        self.doctor_age_entry = tk.Entry(frame, width=30)
        self.doctor_age_entry.grid(row=1, column=1, sticky="w", pady=3)

        tk.Label(frame, text="Phone:").grid(row=2, column=0, sticky="e", padx=5, pady=3)
        self.doctor_phone_entry = tk.Entry(frame, width=30)
        self.doctor_phone_entry.grid(row=2, column=1, sticky="w", pady=3)

        tk.Label(frame, text="Specialization:").grid(row=3, column=0, sticky="e", padx=5, pady=3)
        self.doctor_spec_entry = tk.Entry(frame, width=30)
        self.doctor_spec_entry.grid(row=3, column=1, sticky="w", pady=3)

        tk.Button(frame, text="Add Doctor", command=self.add_doctor).grid(row=4, column=0, columnspan=2, pady=6)

        self.doctor_listbox = self.make_listbox(frame, 5, 12)

        tk.Button(frame, text="Delete Selected", command=self.delete_doctor).grid(row=6, column=0, columnspan=2, pady=4)

        self.refresh_doctors()

    def add_doctor(self):
        try:
            new_doctor = self.hospital.add_doctor(
                self.doctor_name_entry.get(),
                self.doctor_age_entry.get(),
                self.doctor_phone_entry.get(),
                self.doctor_spec_entry.get())
        except ValueError as e:
            messagebox.showerror("Error", str(e))
            return

        messagebox.showinfo("Success", "Doctor added with ID: " + new_doctor.id)
        self.doctor_name_entry.delete(0, tk.END)
        self.doctor_age_entry.delete(0, tk.END)
        self.doctor_phone_entry.delete(0, tk.END)
        self.doctor_spec_entry.delete(0, tk.END)
        self.refresh_doctors()

    def delete_doctor(self):
        id_value = self.selected_id(self.doctor_listbox, "Doctor")
        if id_value is None:
            messagebox.showerror("Error", "Select a doctor to delete first.")
            return

        count = self.hospital.count_doctor_appointments(id_value)
        question = "Delete doctor " + id_value + "?"
        if count > 0:
            question = question + "\nTheir " + str(count) + " appointment(s) will be deleted too."
        if not messagebox.askyesno("Confirm delete", question):
            return

        try:
            deleted = self.hospital.delete_doctor(id_value)
        except ValueError as e:
            messagebox.showerror("Error", str(e))
            return

        if deleted:
            messagebox.showinfo("Deleted", "Doctor " + id_value + " deleted.")
            self.refresh_doctors()
            self.refresh_appointments()
        else:
            messagebox.showerror("Error", "Doctor not found.")

    def refresh_doctors(self):
        self.doctor_listbox.delete(0, tk.END)
        for d in self.hospital.doctors:
            self.doctor_listbox.insert(tk.END, d.display())
        if hasattr(self, "appt_doctor_combo"):
            self.refresh_appointment_choices()

    # -----------------------------------------------------------------
    # Appointments tab
    # -----------------------------------------------------------------
    def build_appointment_tab(self):
        frame = self.appointment_tab

        tk.Label(frame, text="Patient:").grid(row=0, column=0, sticky="e", padx=5, pady=3)
        self.appt_patient_combo = ttk.Combobox(frame, width=40, state="readonly")
        self.appt_patient_combo.grid(row=0, column=1, sticky="w", pady=3)

        tk.Label(frame, text="Doctor:").grid(row=1, column=0, sticky="e", padx=5, pady=3)
        self.appt_doctor_combo = ttk.Combobox(frame, width=40, state="readonly")
        self.appt_doctor_combo.grid(row=1, column=1, sticky="w", pady=3)

        tk.Label(frame, text="Date (YYYY-MM-DD):").grid(row=2, column=0, sticky="e", padx=5, pady=3)
        self.appt_date_entry = tk.Entry(frame, width=30)
        self.appt_date_entry.grid(row=2, column=1, sticky="w", pady=3)
        self.appt_date_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))

        tk.Button(frame, text="Book Appointment", command=self.book_appointment).grid(row=3, column=0, columnspan=2, pady=6)

        self.appointment_listbox = self.make_listbox(frame, 4, 12)

        tk.Button(frame, text="Cancel Selected", command=self.cancel_appointment).grid(row=5, column=0, columnspan=2, pady=4)

        self.refresh_appointment_choices()
        self.refresh_appointments()

    def refresh_appointment_choices(self):
        patient_values = []
        for p in self.hospital.patients:
            patient_values.append(p.id + " - " + p.name)
        doctor_values = []
        for d in self.hospital.doctors:
            doctor_values.append(d.id + " - Dr. " + d.name)

        self.appt_patient_combo["values"] = patient_values
        self.appt_doctor_combo["values"] = doctor_values

        if self.appt_patient_combo.get() not in patient_values:
            self.appt_patient_combo.set("")
        if self.appt_doctor_combo.get() not in doctor_values:
            self.appt_doctor_combo.set("")

    def book_appointment(self):
        patient_text = self.appt_patient_combo.get()
        doctor_text = self.appt_doctor_combo.get()
        if patient_text == "":
            messagebox.showerror("Error", "Choose a patient.")
            return
        if doctor_text == "":
            messagebox.showerror("Error", "Choose a doctor.")
            return

        pid = patient_text.split(" - ")[0]
        did = doctor_text.split(" - ")[0]

        try:
            new_appointment = self.hospital.book_appointment(pid, did, self.appt_date_entry.get())
        except ValueError as e:
            messagebox.showerror("Error", str(e))
            return

        messagebox.showinfo("Success", "Appointment booked with ID: " + new_appointment.id)
        self.refresh_appointments()

    def cancel_appointment(self):
        id_value = self.selected_id(self.appointment_listbox, "Appointment")
        if id_value is None:
            messagebox.showerror("Error", "Select an appointment to cancel first.")
            return

        if not messagebox.askyesno("Confirm cancel", "Cancel appointment " + id_value + "?"):
            return

        try:
            cancelled = self.hospital.cancel_appointment(id_value)
        except ValueError as e:
            messagebox.showerror("Error", str(e))
            return

        if cancelled:
            messagebox.showinfo("Cancelled", "Appointment " + id_value + " cancelled.")
            self.refresh_appointments()
        else:
            messagebox.showerror("Error", "Appointment not found.")

    def refresh_appointments(self):
        self.appointment_listbox.delete(0, tk.END)
        ordered = sorted(self.hospital.appointments, key=lambda a: a.date)
        for a in ordered:
            self.appointment_listbox.insert(tk.END, self.hospital.describe_appointment(a))

    # -----------------------------------------------------------------
    # Search tab
    # -----------------------------------------------------------------
    def build_search_tab(self):
        frame = self.search_tab

        tk.Label(frame, text="Name to search:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.search_entry = tk.Entry(frame, width=30)
        self.search_entry.grid(row=0, column=1, sticky="w", pady=5)
        self.search_entry.bind("<Return>", lambda event: self.run_search())

        tk.Button(frame, text="Search", command=self.run_search).grid(row=1, column=0, columnspan=2, pady=6)

        self.search_listbox = self.make_listbox(frame, 2, 15)

    def run_search(self):
        name = self.search_entry.get()
        if name.strip() == "":
            messagebox.showerror("Error", "Type a name to search for.")
            return

        results = self.hospital.search(name)

        self.search_listbox.delete(0, tk.END)
        if len(results) == 0:
            self.search_listbox.insert(tk.END, "No matches found.")
        else:
            for r in results:
                self.search_listbox.insert(tk.END, r.display())


def main():
    root = tk.Tk()
    app = HospitalApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()